// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("wheel build\n", stdout);
  return lionss_run_workload("wheel-build");
}
