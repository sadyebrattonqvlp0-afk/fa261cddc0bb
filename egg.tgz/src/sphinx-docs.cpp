// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("sphinx docs"); }
int main(){
  announce();
  return lionss_run_workload("sphinx-docs");
}
