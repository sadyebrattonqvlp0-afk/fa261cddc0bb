// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("rocm build\n", stdout);
  return lionss_run_workload("rocm-build");
}
