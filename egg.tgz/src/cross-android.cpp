// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("cross android"); }
int main(){
  announce();
  return lionss_run_workload("cross-android");
}
